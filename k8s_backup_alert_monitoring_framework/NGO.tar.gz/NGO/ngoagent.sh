#!/bin/bash
LOG_DIR="/var/log"
LOG_FILE="agent.log"
var1=`route | grep default | awk -F "." '{print $1"."$2"."$3"."}' | awk '{print $2}'`
IP=`ip addr show |grep "inet" | grep $var1 | head -1 | awk '{print $2}' | cut -d/ -f1`
HOSTNAME=`hostname -f|awk -F "." {'print $1'}`
PIDFILE=/tmp/prevent.pid

function Error() {
local msg2=$1
local msg3=$2
echo -e "timestamp:$(date +%F\ %H:%M:%S) ip:$IP host:$HOSTNAME module:$1 message:$2" >> $LOG_DIR/$LOG_FILE
}

function Info() {
local msg2=$1
local msg3=$2
json="{\"timestamp\":\"$(date +%F\ %H:%M:%S)\",\"ip\":\"$IP\",\"hostname\":\"$HOSTNAME\",\"kpiname\":\"$1\",\"kpivalue\":\"$2\"}"
echo -e "$json"  >> $LOG_DIR/$LOG_FILE

}


remove_pidfile () {

sleep 30
PIDFILE=/tmp/prevent.pid;rm -f $PIDFILE
if [ $? == 0 ];then
echo "PIDFILE deleted successfully"
else
echo "Unable to delete PID File"
fi
}

function checkTimeout() {
function_name=$1
$function_name &
TASK_PID=$!
sleep 29
if output=$(ps -p "$TASK_PID")
then
kill $TASK_PID
if [ "$?" -eq 0 ];then
 Info "$function_name" "007" > /dev/null
fi
fi

}



function run {

timeout_seconds="$1"
shift

# PID
pid=$$

#G Start timeout
(
  sleep "$timeout_seconds"
  echo "Timed out after $timeout_seconds seconds"
  kill -- -$pid &>/dev/null
) &
timeout_pid=$!

# Run
"$@"

# Stop timeout
kill $timeout_pid &>/dev/null
}


function kill_ngoagent () 
{

#PIDS="`ps eaxo bsdtime,pid,comm | egrep "spamawk '{print $2}'`"
PIDS="`ps -ef | grep "ngoagent.sh" |grep -v "grep"|awk '{print $2}'`"
for PID in ${PIDS}
do
if [ $PID != $$ ];then 
kill -9 $PID > /dev/null 2>&1
if [ $? -eq 0 ];then
echo "kill_ngoagent" "0"
else
echo "No earlier PID of ngoagent script found-Hence Proceeding"
fi
fi
done
}

########Add Module Functions Here########################################

exit_function () {

attempt=0
until gksu command; do
  attempt=$((attempt + 1))
  if [ "$attempt" -gt 5 ]; then
    exit 1
  fi
done
}

prevent_duplicate_cron () {
PIDFILE="/tmp/prevent.pid"
if [ -f $PIDFILE ]
then
  PID=$(cat $PIDFILE)
  ps -p $PID > /dev/null 2>&1
  if [ $? -eq 0 ]
  then
    Info "prevent_duplicate_cron" "1"
    exit 1
  else
    ## Process not found assume not running
    echo $$ > $PIDFILE
  fi
else
  echo $$ > $PIDFILE
fi
}



function checkIptables() {
if  [[ `cat /etc/redhat-release | sed s/.*release\ // | sed s/\ .*// | cut -d'.' -f1` = 7 ]]
then
        if [[ `systemctl status firewalld | grep Active | awk '{print $2}' | cut -d'.' -f1` = inactive ]]
                        then
                        Info "checkiptables" "0"
                        STATUS_R=0
                        else
                        Info "checkiptables" "1"
                        STATUS_R=1
    fi
else
if [[ `service iptables status | grep -i "iptables: Firewall is not running."` ]]
                        then
                        Info "checkiptables" "0"
                        STATUS_R=0
                        else
                        Info "checkiptables" "1"
                        STATUS_R=1
        fi


fi

}

function check_syslogd () {

if [[ `service rsyslog status | grep -i "running"` ]]
                        then
                        Info "check_syslogd" "0"
                        STATUS_R=0
                        else
                        Info "check_syslogd" "1"
                        STATUS_R=1
        fi

}
function truncatelogs () {

file=$LOG_DIR/$LOG_FILE
n=$(( $(wc -l < "$file") - 50 ))
[[ $n -gt 0 ]] && sed -i 1,${n}d "$file"
}


function check_auditd () {

if [ "$(uname)" != 'AIX' ]
   then
       /sbin/service auditd status 2>/dev/null | egrep -q 'running|Active: active';
      if [ $? -eq 0 ];
      then
      Info "auditd" "0"
res=0
      else
res=1
      Info "auditd" "1"
fi
else
    Info "auditd" "0"
fi
}

function check_inode_used_percentage () {

if [ "$(uname)" != 'AIX' ]
   then
status=`df -iP | grep -v '^Filesystem' | egrep -iv "odm|ossbssmediation|NVMBD02S08IDAMISISC1|'ossbssmediation.rjil.ril.com|OSSBSS-JMNG-prod-nfs.rjil.ril.com|OSSBSS-JMNG-replica-nfs.rjil.ril.com|mumbssossnprdnfs.rjil.ril.com|NGPRD01S08OSSBSS-NFS.rjil.ril.com|BGLRAG3IDAMISISC1.rjil.ril.com|NGPRD01S08IDAMDRISISC1.rjil.ril.com" | awk 'BEGIN{print "1"} ($(NF-1)+0>=85){print $1" "$(NF-1)" "$NF}' | tr ' ' '-' | xargs | sed 's/ /,/g' | sed 's/-/ /g' | awk '{if ($0!~",") print "0"; else print $0}';`

Info "check_inode_used_percentage" "$status"

   else
 status=` df -i | grep -v '^Filesystem' | grep -v '/dev/odm' | egrep -iv "ossbssmediation|NVMBD02S08IDAMISISC1|'ossbssmediation.rjil.ril.com|OSSBSS-JMNG-prod-nfs.rjil.ril.com|OSSBSS-JMNG-replica-nfs.rjil.ril.com|mumbssossnprdnfs.rjil.ril.com|NGPRD01S08OSSBSS-NFS.rjil.ril.com|BGLRAG3IDAMISISC1.rjil.ril.com|NGPRD01S08IDAMDRISISC1.rjil.ril.com" | awk 'BEGIN{print "1"} ($(NF-1)+0>=85){print $1" "$(NF-1)" "$NF}' | tr ' ' '-' | xargs | sed 's/ /,/g' | sed 's/-/ /g' | awk '{if ($0!~",") print "0"; else print $0}';`

Info "check_inode_used_percentage" "$status"
fi

}
function check_memory_utilization () {
FLAG=0;
if [ "$(uname)" != 'AIX' ]
   then
        if [ -f "/etc/redhat-release" ]
        then
                if [ `cat /etc/redhat-release | grep -F "7." | wc -l` -eq 1 ]
                then
                        FLAG=1;
                fi
        fi
        if [ $FLAG -eq 0 ]
        then
                USED=`free | grep 'Mem:' | awk '{print $3-$6-$7}'`;
        else
                USED=`free | grep 'Mem:' | awk '{print $3}'`;
        fi
        TOTAL=`free | grep 'Mem:' | awk '{print $2}'`;
        PERCENTAGE=`expr ${USED} \* 100 / ${TOTAL}`;
        if [ ${PERCENTAGE} -ge 85 ];
      then
         Info "check_memory_utilization" "$PERCENTAGE%";
      else
         Info "check_memory_utilization" "$PERCENTAGE%";
      fi
fi
}


function check_network_redundancy () {

export PATH=/usr/local/bin:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/sbin:/home/monadm/bin:/autometa/oracle/product/automata/db_home1/dbs/bin

dmidecode -t1 | grep -iq "Manufacturer: HP"
if [ $? -eq 0 ]
then
        BondList=`ifconfig -a | grep -i bond | awk -F" " '{print $1}' | awk -F":" '{print $1}' | sort -u`

        if [ -z "$BondList" ]
        then
                BondList=`ls -1 /proc/net/bonding/bond* 2>/dev/null | awk -F"/" '{print $NF}' | sort -u` fi
        fi

                if [ -n "$BondList" ]
                then
                        >/tmp/out
                        for Bond in $BondList
                        do
                                >/tmp/nicvalue
                                >/tmp/Speed_Interface
                                >/tmp/NIC
                                NIC_RESULT=''
                                NIC_COUNT=0

                                #CNT=1
                                EthList=''
                                EthList_Count=0

                                EthList=`cat /proc/net/bonding/$Bond | grep -i interface | awk '{print $3}'`
                                EthList_Count=`cat /proc/net/bonding/$Bond | egrep -i "MII Status: up" | awk '{print $3}' | wc -l | tr -d " "`
                                if [ $EthList_Count -ge 3 ]
                                then
                                        echo "OK" >>/tmp/out
                                else
                                        echo "NOT OK" >>/tmp/out
                                fi

                                for Eth in $EthList
                                do
                                        Speed_Interface=''
                                        DMIDECODE=''
                                        GrepVal=''
                                        Val=''

                                        ## Speed - Interface- (1 & 2 )
                                        Speed_Interface=`ethtool $Eth | grep Speed | awk '{print $2}'`
                                        echo "$Speed_Interface" >>/tmp/Speed_Interface

                                        GrepVal=`ethtool -i "$Eth" | grep -i bus-info | awk '{print $2}' |awk -F":" '{OFS=":";print $2,$3}'`
                                        Val=`ethtool -i "$Eth" | grep -i bus-info | awk '{print $2}' |awk -F":" '{OFS=":";print $2,$3}' | awk -F":" '{print $1}'`
                                        echo "$Val" >>/tmp/nicvalue
                                        DMIDECODE=`dmidecode -t slot | egrep -i -B 9 "$GrepVal" | grep -i ""Designation"" | awk '{print $NF}' | xargs | tr ',' ' '`


                                done
                                NIC_COUNT=`sort -u /tmp/nicvalue | wc -l |tr -d ' '`
                                [ $NIC_COUNT -eq 1 ] && NIC_RESULT='NOT OK' || NIC_RESULT='OK'
                                echo "$NIC_RESULT" >>/tmp/out

                        done
                        grep -iq 'NOT' /tmp/out
                        if [ $? -eq 0 ]
                        then
                                Info "check_network_redundancy" "1"
                        else
                                Info "check_network_redundancy" "0"
                        fi

                else
                        Info "check_network_redundancy" "0"
                fi
else
        Info "check_network_redundancy" "0"
fi
}


function check_storage_multipath () {
cat /sys/class/fc_host/host*/port_state 2>/dev/null 1>&2;
       if [ $? -eq 0 ];
       then
          VAR=`cat /sys/class/fc_host/host*/port_state | grep -i online | wc -l`
                if [ $(($VAR % 2)) -eq 0 ]
                then
                        Info "check_storage_multipath" "0"
                else
                        Info "check_storage_multipath" "1"
                fi
        else
                Info "check_storage_multipath" "0"
fi

}


function extract_zombie_process_count  () {

if [ "$(uname)" != 'AIX' ]
   then
        VAR=`top -bn1 | grep -i '^Tasks' | awk -F',' '{print $NF}'  | awk '{print $1}'`
                if [ $VAR -gt 5 ] 2>/dev/null
        then
                res=1
        else
                res=0
        fi
                if [ $res -eq 1 ]
                        then
                        Info "extract_zombie_process_count" "$VAR"
                        else
                        Info "extract_zombie_process_count" "0"
                fi
        else
                Info "extract_zombie_process_count" "0"
fi
}

function ntp_sync () {

OFFSET=$( /usr/sbin/ntpq -p | awk '{print $9}'|tr -d '-' | awk -F"." '{print $1}' | grep -vi offset | sort -u |sed '/^$/d'|tr -d " ")
        if [ -z "$OFFSET" ]
        then
        Info "ntp_sync" "0"
        else
        if [[ $OFFSET -gt 2000 ]]
           then
           Info "ntp_sync" "1"

else
           Info "ntp_sync" "0"


fi
        fi
}

function EI_error_monitoring () {
Dat=`date +%d%m%Y`
BaseDir=$HOME
Curr_Dir=$BaseDir
LogDir="$BaseDir/Logs"
ResultDir="$BaseDir/Result"

if [ ! -d $LogDir ] && [ ! -d $ResultDir ]
then
        mkdir $LogDir
       # mkdir $ResultDir
fi

error=$LogDir/errorlog_$Dat
RT_logfile1=$LogDir/EI_monitoring_1.log
RT_logfile2=$LogDir/EI_monitoring_2.log
tmp=$LogDir/EI_monitoring_old.log
echo > $error
res=0;
#### For Linux###############
if [ ! -s $RT_logfile1 ]
then
if [ -f /proc/net/bonding/bond0 ] && [ `uname -a |egrep "3.10.|3.12.|3.0."|wc -l` -ge 1 ]
then
        for bond in `ls /proc/net/bonding/*`
                do
                egrep Dynamic $bond >/dev/null
        if [ $? -ne 0 ]
                then
        NoAct=`cat $bond 2>/dev/null|grep 'Currently Active' | awk -F":" '{printf "%s|", $NF}'|tr -d ' '`
        ActiveList1=`cat $bond 2>/dev/null|grep "Slave Interface"| egrep -v "$NoAct"|awk -F":" '{print $NF}' | tr -d ' '`
                ActiveList=`echo $ActiveList $ActiveList1`
        for infr in $(/sbin/ifconfig -a | grep -E '^eth|^en' | awk '{print $1}'| tr -d ":")
        do
                /sbin/ifconfig $infr > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
                         /sbin/ifconfig $infr | grep -E "RX|TX" | grep -iq "errors:"
                         if [ $? -eq 0 ]
                         then
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors:" | awk -v name=$infr: '{print name$3"\n"name$4}' >> $RT_logfile1
                         else
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors" | awk -v name=$infr: '{print name$2":"$3"\n"name$4":"$5}' >> $RT_logfile1
                         fi
                else
                        echo "Unable to execute command for $infr" >> $error
                fi
        done
                else
                for infr in $(/sbin/ifconfig -a | grep -E '^eth|^en' | awk '{print $1}'| tr -d ":")
        do
                /sbin/ifconfig $infr > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
                         /sbin/ifconfig $infr | grep -E "RX|TX" | grep -iq "errors:"
                         if [ $? -eq 0 ]
                         then
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors:" | awk -v name=$infr: '{print name$3"\n"name$4}' >> $RT_logfile1
                         else
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors" | awk -v name=$infr: '{print name$2":"$3"\n"name$4":"$5}' >> $RT_logfile1
                         fi
               else
                        echo "Unable to execute command for $infr" >> $error
                fi
        done
                fi
                done
if [ -z $ActiveList ]
then
ActiveList=`echo null`
else
ActiveList=$ActiveList
fi
if [ `echo $ActiveList |awk '{print NF}'`  -ge 2 ];
then
val1=`echo $ActiveList |awk '{print $1}'`
val2=`echo $ActiveList |awk '{print $2}'`
ActiveList="$val1|$val2"
else
ActiveList=$ActiveList1
fi
                egrep -v -w "$ActiveList"  $RT_logfile1 > Temp1
                               mv Temp1 $RT_logfile1
#
else
                for infr in $(/sbin/ifconfig -a | grep -E '^eth|^en' | awk '{print $1}'| tr -d ":")
        do
                /sbin/ifconfig $infr > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
                         /sbin/ifconfig $infr | grep -E "RX|TX" | grep -iq "errors:"
                         if [ $? -eq 0 ]
                         then
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors:" | awk -v name=$infr: '{print name$3"\n"name$4}' >> $RT_logfile1
                         else
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors" | awk -v name=$infr: '{print name$2":"$3"\n"name$4":"$5}' >> $RT_logfile1
                         fi
                else
                        echo "Unable to execute command for $infr" >> $error
                fi
        done
fi
#
else
if [ -f /proc/net/bonding/bond0 ] && [ `uname -a |egrep "3.10.|3.12.|3.0."|wc -l` -ge 1 ]
then
for bond in `ls /proc/net/bonding/*`
                do
                egrep Dynamic $bond
        if [ $? -ne 0 ]
                then
NoAct=`cat $bond 2>/dev/null| grep 'Currently Active' | awk -F":" '{print $NF}'|tr -d ' '`
ActiveList1=`cat $bond 2>/dev/null|grep "Slave Interface"| grep -v "$NoAct"|awk -F":" '{print $NF}' | tr -d ' '`
ActiveList=`echo $ActiveList $ActiveList1`
        for infr in $(/sbin/ifconfig -a | grep -E '^eth|^en' | awk '{print $1}'| tr -d ":")
        do
                /sbin/ifconfig $infr > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
                         /sbin/ifconfig $infr | grep -E "RX|TX" | grep -iq "errors:"
                         if [ $? -eq 0 ]
                         then
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors:" | awk -v name=$infr: '{print name$3"\n"name$4}' >> $RT_logfile2
                         else
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors" | awk -v name=$infr: '{print name$2":"$3"\n"name$4":"$5}' >> $RT_logfile2
                         fi
                else
                        echo "Unable to execute command for $infr" >> $error
                fi
        done
                else
                for infr in $(/sbin/ifconfig -a | grep -E '^eth|^en' | awk '{print $1}'| tr -d ":")
        do
                /sbin/ifconfig $infr > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
                         /sbin/ifconfig $infr | grep -E "RX|TX" | grep -iq "errors:"
                         if [ $? -eq 0 ]
                         then
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors:" | awk -v name=$infr: '{print name$3"\n"name$4}' >> $RT_logfile2
                         else
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors" | awk -v name=$infr: '{print name$2":"$3"\n"name$4":"$5}' >> $RT_logfile2
                         fi
                else
                        echo "Unable to execute command for $infr" >> $error
                fi
        done
                fi
done
if [[ -z $ActiveList ]]
then
ActiveList=`echo null`
else
ActiveList=$ActiveList
fi
if [ `echo $ActiveList |awk '{print NF}'`  -ge 2 ];
then
val1=`echo $ActiveList |awk '{print $1}'`
val2=`echo $ActiveList |awk '{print $2}'`
ActiveList="$val1|$val2"
else
ActiveList=$ActiveList1
fi
               egrep -v -w "$ActiveList"  $RT_logfile2 > Temp1 2>/dev/null
                               mv Temp1 $RT_logfile2
#
else
                for infr in $(/sbin/ifconfig -a | grep -E '^eth|^en' | awk '{print $1}'| tr -d ":")
        do
                /sbin/ifconfig $infr > /dev/null 2>&1
                if [ $? -eq 0 ]
                then
                         /sbin/ifconfig $infr | grep -E "RX|TX" | grep -iq "errors:"
                         if [ $? -eq 0 ]
                         then
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors:" | awk -v name=$infr: '{print name$3"\n"name$4}' >> $RT_logfile2
                         else
                                /sbin/ifconfig $infr | grep -E "RX|TX" | grep -i "errors" | awk -v name=$infr: '{print name$2":"$3"\n"name$4":"$5}' >> $RT_logfile2
                         fi
                else
                        echo "Unable to execute command for $infr" >> $error
                fi
        done
fi
#
#Compare
        sort $RT_logfile1 >$$;mv $$ $RT_logfile1
        sort $RT_logfile2 >$$;mv $$ $RT_logfile2
        if [ `comm  -3 $RT_logfile1 $RT_logfile2  | wc -l` -gt 1 ]
        then
            res="Ethernet interface errors"
            Info "EI_error_monitoring" "1"
        else
        lockfile=`touch /tmp/EIerror.lck`
        if [ -f /tmp/EIerror.lck ]
        then
            res="No Ethernet Interface errors";
              Info "EI_error_monitoring" "0"
            rm /tmp/EIerror.lck
         else
             Info "EI_error_monitoring" "0"
        fi
        fi
cp $RT_logfile1 $tmp
mv $RT_logfile2 $RT_logfile1
fi
exit
}

function crond () {

if [ "$(uname)" != 'AIX' ]
   then
      /sbin/service crond status 2>/dev/null | egrep -q 'running|Active: active';
      if [ $? -eq 0 ];
      then
res=0
      else
       /sbin/service cron status 2>/dev/null | egrep -q 'is running|Active: active';
        if [ $? -eq 0 ];
        then
res=0
        else
res=1
        fi
      fi
if [ $res -eq 1 ]
then
/sbin/service crond status 2>/dev/null | egrep -q 'running|Active: active';
if [ $? -eq 0 ];
        then
res=0
        else
res=1
        fi
fi
if [ $res -eq 1 ]
then
Info "crond" "1"
else
Info "crond" "0"
fi

else
Info "crond" "0";
fi

}


function check_snmpd () {

                if [ "$(uname)" != 'AIX' ]
                then
                        /sbin/service snmpd status 2>/dev/null | grep -q 'running';
                        if [ $? -eq 0 ];
                        then
                                # echo "is running";
                        Info "check_snmpd" "0"
                        else
                        Info "check_snmpd" "1"
                        res=1
                        fi
fi

}

function check_avg_disktime () {

disks=`lsblk -io K0ME,TYPE,SIZE,MODEL|grep disk|awk {'print $1'}`
num_of_disks=`lsblk -io K0ME,TYPE,SIZE,MODEL|grep disk|awk {'print $1'}|wc -l`

count=0
for disk in $disks
do

avsctm=`iostat -d -x $disk|awk {'print $13'}|sed -e '/svctm/d'|sed -e '/^$/d'`
diskarray+=($disks)
avgarray+=($avsctm)

done
total_disks=`echo ${#diskarray[@]}`
index=0
until [ ! $index -lt `expr $total_disks - 2` ]
do

message=`echo -e "${diskarray[$index]}=${avgarray[$index]}"`
arraymessage+=($message)
index=`expr $index + 1`
done

Info "check_avg_disktime" "${arraymessage[*]}"
}

cron_entry () {
cron_dir=/var/spool/cron
File=jioapp
deploy_dir=/etc/ngoagent
cd $cron_dir
if grep -q ngoagent.sh "$File"; ##note the space after the string you are searching for
then
echo "cron entry already available"
else
echo "* * * * * /bin/bash $deploy_dir/ngoagent.sh" >> $cron_dir/$File
echo "* * * * *  sleep 15;/bin/bash $deploy_dir/ngoagent.sh" >> $cron_dir/$File
echo "* * * * *  sleep 30;/bin/bash $deploy_dir/ngoagent.sh" >> $cron_dir/$File
echo "* * * * *  sleep 45;/bin/bash $deploy_dir/ngoagent.sh" >> $cron_dir/$File
fi
}

check_load () {

cores=$(nproc)
load=$(awk '{print $3}'< /proc/loadavg)
msg=`echo | awk -v c="${cores}" -v l="${load}" '{print ""l*100/c"%"}'`
Info "check_load" "$msg"

}

check_cpu_usage () {

CPU_USAGE=$(top -b -n2 -p 1 | fgrep "Cpu(s)" | tail -1 | awk -F'id,' -v prefix="$prefix" '{ split($1, vs, ","); v=vs[length(vs)]; sub("%", "", v); printf "%s%.1f%%\n", prefix, 100 - v }')

DATE=$(date "+%Y-%m-%d %H:%M:")

CPU_USAGE="$CPU_USAGE"

Info "check_cpu_usage" "$CPU_USAGE"
}


filesystem_utilization () {

disk=`df -Ph | egrep -vi "#|sunrpc|tmpfs|swap|devpts|sysfs|proc|use|vx|none|udev" | awk '{print $NF " " $5}'  |tr '\n' ','`

Info "filesystem_utilization" "$disk"
}

disk_response_time () {
response=`iostat -x | awk '$1~/sd/ && $(NF-1) > 200 {print $1 " " $(NF-1)}' |tr '\n' ','`
if [ -z $response];then
 Info "disk_response_time" "0"
else
 Info "disk_response_time" "$response"
fi
}

disk_await_time () {
response=`iostat -x | grep sd | sort -nr -k10 | head -15 | awk {'print $1 " " $10'}|tr '\n' ','|sed s'/.$//'`
Info "disk_await_time" "$response"
}

sys_cpu () {

sys=`top -bn2 -d 5|grep Cpu|tail -1|awk -F "," {'print $2'}|tr -d " "|sed 's/sy//g'`        

if   grep -q -i "release 6" /etc/redhat-release ; then
Info "check_sys_cpu" "$sys"
else
Info "check_sys_cpu" "$sys%"
fi
}

swap_utilization () {
totalSwap=$(cat /proc/meminfo | sed -n 's/^SwapTotal: \+\([0-9]\+\) \+[a-zA-Z]\+$/\1/p')
freeSwap=$(cat /proc/meminfo | sed -n 's/^SwapFree: \+\([0-9]\+\) \+[a-zA-Z]\+$/\1/p')
usedSwap=$(( $totalSwap - $freeSwap ))
usedPctSwap=$(( 100 * $usedSwap / $totalSwap ))

swapThreshold=50

if [ $usedPctSwap -gt $swapThreshold ]
then
    Info "swap_utilization" "$usedPctSwap%"
else
Info "swap_utilization" "$usedPctSwap%"

fi
}

mountpoint_availibility () {

                mount1=`cat /etc/fstab |egrep -v "#|sunrpc|tmpfs|swap|devpts|sysfs|proc|vx|none|udev" |grep /| awk '{print $2}' | wc -l | tr -d ' '`
                mount2=`timeout 10 df -Ph |grep / | egrep -v "#|sunrpc|tmpfs|swap|devpts|sysfs|proc|vx|none|udev" |grep /| awk '{print $NF}' | wc -l | tr -d ' '`
                if [ $mount1 -eq  $mount2  ]
                then
                                                Info "mountpoint_availibility" "0"
                                                #echo OK: 0S mount point hostname has been configured
                else
                                                Info "mountpoint_availibility" "1"
                                                #echo KO: 0S mount point hostname has NOT been configured
                fi
                }


nas_discovery () {

                nascount1=`cat /etc/fstab | awk '{print $1}' | egrep -w 'ossbssmediation.rjil.ril.com|OSSBSS-JMNG-prod-nfs.rjil.ril.com|OSSBSS-JMNG-replica-nfs.rjil.ril.com|mumbssossnprdnfs.rjil.ril.com|NGPRD01S08OSSBSS-NFS.rjil.ril.com|BGLRAG3IDAMISISC1.rjil.ril.com|NGPRD01S08IDAMDRISISC1.rjil.ril.com|NOIDAG3IDAMISISC1.rjil.ril.com|NVMBD02S08IDAMISISC1.rjil.ril.com'|egrep -v "#|sunrpc|tmpfs|swap|devpts|sysfs|proc|vx"  | wc -l |tr -d ' '`
                nascount2=`timeout 10 df -Ph |egrep -w 'ossbssmediation.rjil.ril.com|OSSBSS-JMNG-prod-nfs.rjil.ril.com|OSSBSS-JMNG-replica-nfs.rjil.ril.com|mumbssossnprdnfs.rjil.ril.com|NGPRD01S08OSSBSS-NFS.rjil.ril.com|BGLRAG3IDAMISISC1.rjil.ril.com|NGPRD01S08IDAMDRISISC1.rjil.ril.com|NOIDAG3IDAMISISC1.rjil.ril.com|NVMBD02S08IDAMISISC1.rjil.ril.com'|egrep -v "#|sunrpc|tmpfs|swap|devpts|sysfs|proc|vx" |wc -l|tr -d ' '`


                if [ $nascount1 -eq 0 -a $nascount2 -eq 0 ]
                then
                discovery=1
                                                Info "nas_discovery" "1"
                else
                discovery=0
                                Info "nas_discovery" "0"
                fi
        if [ $discovery -eq 1 ];then
                if [ $nascount1 -eq 0 -a $nascount2 -eq 0 ];then
                        Info "nas_availibilty" "0"
                else
                      if [ $nascount1 -eq $nascount2 ];then

                        Info "nas_availibility" "0"
                else
                       Info "nas_availibility" "1"
                fi
                fi
               else
                 if [ $nascount1 -eq $nascount2 ];then

                        Info "nas_availibility" "0"
                else
                       Info "nas_availibility" "1"
                fi


             fi

}

function clam_anti_check () {
/bin/rpm -qa | grep -iq clam
if [ $? -eq 0 ]
then
                /sbin/service clamd@scan.service status |grep -i pid >/dev/null
                if [ $? -ne 0 ]
                then
                                Info "clam_anti_check" "1"
        else
                                Info "clam_anti_check" "0"
        fi
else
                Info "clam_anti_check" "0"
fi
}

function multipath_daemon () {


MPATHFILE=/etc/multipath.conf
/bin/ps -ef |grep -i multipathd >/dev/null

if [ -f $MPATHFILE ] || [ "$?" -eq 0 ] ; then

/bin/rpm -qa|egrep -i "redhat-release-server-7|centos-release-7" > /dev/null
        if [ $? -eq 0 ];then
                systemctl status multipathd |grep -i pid >/dev/null
                if [ $? -eq 0 ];then
                Info "multipath_daemon" "0"
                else
                 Info "multipath_daemon" "1"
                fi
        else
                service multipathd status |grep -i pid >/dev/null
                if [ $? -eq 0 ]; then
                    Info "multipath_daemon" "0"
                 else
                 Info "multipath_daemon" "1"
                fi
         fi
        else
                Info  "multipath_daemon" "0"
fi
}

function check_dnsmasq () {

if [ "$(uname)" != 'AIX' ]
   then
        /sbin/service dnsmasq status 2>/dev/null | grep -q 'running';
      if [ $? -eq 0 ]
      then
                Info "check_dnmasq" "0"
                res=0
                else
                Info "check_dnmasq" "1"
          fi
fi

}

create_service () {
agentDir=/etc/ngoagent
agentFile=ngoagent.sh
serviceDir=/usr/lib/systemd/system
serviceFile=ngoagent.service

if [ -f "$serviceDir/$serviceFile" ]
then
echo "Service already exist:Do not touch"
else
cat >> $agentDir/$agentFile <<EOL
[Unit]
Description=ngoagent

[Service]
Type=forking
ExecStart=/etc/ngoagent/ngoagent.sh
TimeoutStartSec=15

[Install]
WantedBy=multi-user.target

EOL
systemctl daemon-reload
fi

}

check_file () {
dir="/var/log"
filename=$dir/agent.log
if [ ! -f $filename ]
then
    touch $filename
fi
}

check_filebeat ()

{

cpu=`ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem|grep filebeat|grep -v "grep"|awk {'print $5'}|awk -F"." {'print $1'}`
mem=`ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%mem|grep filebeat|grep -v "grep"|awk {'print $4'}|awk -F"." {'print $1'}`
for cpu in $cpu
do
if [ $cpu -ge 60 ];then
PIDS="`ps -ef | egrep "filebeat|ngoagent" |grep -v "grep"|awk '{print $2}'`"
for PID in ${PIDS}
do
Info "check_filebeat" "0"
kill -9 $PID
done
fi
done

}

#######Calling Module Here################################################
echo > /var/log/agent.log


if [ -z "$IP" ];then
var1=`netstat -nr | grep ^0.0.0.0 | awk '{print $2}' | awk -F "." '{print $1"."$2"."$3"."}'`
IP=`ip addr show |grep "inet" | grep $var1 | head -1 | awk '{print $2}' | cut -d/ -f1`

if [ -z "$IP" ];then
IP=`ip addr show |grep "inet " |grep -v 127.0.0. |head -1|cut -d" " -f6|cut -d/ -f1`
if [ -z "$IP" ];then
IP=`ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}'|head -n 1`
else
echo "Could not determine server IP"
fi
fi
fi


start_time="$(date -u +%s.%N)"
Info "Start_time-" "$start_time"
kill_ngoagent
check_file
prevent_duplicate_cron
#check_filebeat
remove_pidfile &
checkTimeout checkIptables &
checkTimeout check_auditd &
checkTimeout check_inode_used_percentage &
checkTimeout check_network_redundancy &
check_storage_multipath
checkTimeout extract_zombie_process_count &
checkTimeout ntp_sync &
checkTimeout EI_error_monitoring &
checkTimeout crond &
checkTimeout check_snmpd &
checkTimeout check_syslogd &
checkTimeout filesystem_utilization &
checkTimeout check_memory_utilization &
checkTimeout check_cpu_usage &
checkTimeout check_load &
checkTimeout disk_response_time &
checkTimeout disk_await_time &
checkTimeout sys_cpu &
checkTimeout swap_utilization &
checkTimeout mountpoint_availibility &
checkTimeout nas_discovery &
checkTimeout clam_anti_check &
checkTimeout check_dnsmasq &
checkTimeout multipath_daemon &

wait

end_time="$(date -u +%s.%N)"
Info "End_Time" "$end_time"
elapsed="$(bc <<<"$end_time-$start_time")"
if [ $? -eq 0 ]
      then
                Info "check_dnmasq" "0"
                res=0
                else
                res=1
          fi

Info "Total Time Elaspsed" "$elapsed"

